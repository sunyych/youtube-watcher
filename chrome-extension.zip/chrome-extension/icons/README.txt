Add your extension icons here (png):
- icon16.png
- icon32.png
- icon48.png
- icon128.png

If you don't add icons, Chrome may show a default puzzle icon.
